package com.ogryzok.manualharvest.client.render;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ManualHarvestPelvisModel extends ModelBase {
    private final ModelRenderer base;
    private final ModelRenderer arm;
    private final ModelRenderer tip;

    public ManualHarvestPelvisModel() {
        this.textureWidth = 64;
        this.textureHeight = 32;

        this.base = new ModelRenderer(this, 22, 20);
        this.base.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.base.addBox(-0.7F, -0.7F, -1.8F, 2, 3, 2, 0.0F);
        this.base.rotateAngleY = (float) Math.toRadians(-90.0D);

        this.arm = new ModelRenderer(this, 20, 24);
        this.arm.setRotationPoint(1.1F, 1.4F, -0.8F);
        this.arm.addBox(-4.6F, -0.3F, -0.7F, 5, 1, 1, 0.0F);
        this.arm.rotateAngleZ = (float) Math.toRadians(42.5D);
        this.base.addChild(this.arm);

        this.tip = new ModelRenderer(this, 42, 14);
        this.tip.setRotationPoint(-4.6F, 0.0F, 0.0F);
        this.tip.addBox(-0.9F, -0.35F, -0.75F, 1, 1, 1, 0.0F);
        this.arm.addChild(this.tip);
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        this.base.render(scale);
    }
}
